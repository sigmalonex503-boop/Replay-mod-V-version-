# Replay Core for Levi Launcher — Bootstrap v0.1

This is the first **native Levi mod project** for a new Replay implementation. It is deliberately a small, testable bootstrap based on LeviLaunchroid's official `examples/full-cpp-mod` template.

## What this version does
- Builds an ARM64 Android native `.levipack` using LeviLaunchroid's public Preloader SDK.
- Registers a Mod Menu module and config values.
- Provides test HUD buttons/callbacks and persistent config.
- Logs successful lifecycle/config loading, so the first device test can establish that the native mod loads correctly.

## What it does NOT do yet
This is **not a working recorder/player yet**. It does not capture Minecraft world state, save replay files, seek a timeline, or control a cinematic camera. Those features require verified game interfaces/hooks and will be implemented after this bootstrap is confirmed to load.

## Build
Use a Windows machine with Git, PowerShell, Android NDK, and the SDK paths configured, or use the GitHub Actions workflow in `.github/workflows/build.yml`.

The project uses the official LeviLaunchroid `examples/full-cpp-mod` build setup. For local build, run the provided `build.ps1` as documented in the upstream template. The output should be a `.levipack` under `dist/arm64-v8a/`.

## First device test
1. Import the generated `.levipack` into Levi Launcher.
2. Enable **Replay Core — Bootstrap** in the in-game Mod Menu.
3. Confirm that the module appears, its settings can be changed, and the test HUD buttons respond.
4. Send back the build log or screenshot if any step fails. Do not enable it alongside the existing BedrockReplay mod for the first test; disable the old replay mod to avoid conflicts.

## Next milestone
After bootstrap loading is verified, implement the first actual replay capability against the exact Minecraft/Levi build: begin with recording and replaying a minimal, explicitly supported event/state, then expand to frame storage, seeking, camera keyframes, and scene visibility.

## License note
The source is derived from LeviLaunchroid's official example. Preserve the upstream license and attribution notices included in the source distribution and comply with any licenses of code later reused from Playback.
